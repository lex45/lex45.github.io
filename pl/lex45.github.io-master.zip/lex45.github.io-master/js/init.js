(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.carousel').carousel();

  }); // end of document ready
})(jQuery); // end of jQuery name space